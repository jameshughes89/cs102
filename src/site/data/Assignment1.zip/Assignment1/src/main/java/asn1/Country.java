package asn1;

public class Country {

}
